
def crop_image(image, top_left, bottom_right):
    """
    Takes a numpy.ndarray and crop it to the given dimensions
    :param image: numpy.ndarray representing the image
    :param top_left: a tuple of the form (x, y)
    :param bottom_right: a tuple of the form (x, y)
    :return: a cropped image represented by a numpy.ndarray cropped to the given dimensions
    """

    x1, y1 = top_left
    x2, y2 = bottom_right

    return image[y1:y2 + 1, x1:x2 + 1]
