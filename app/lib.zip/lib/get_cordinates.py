from lib.structure import TableStructure
from typing import Tuple, List
from functools import partial

def _convert_coordinate_system(point, dest_space_width, dest_space_height,
                               src_space_width, src_space_height):
    """
    Converts a point from src coordinate system to dest coordinate system.
    :point (x,y) in the src coordinate system
    :param dest_space_width: Height of the dest coordinate system
    :param dest_space_height: Width of the dest coordinate system
    :param src_space_width: Height of the source coordinate system
    :param src_space_height: Width of the source coordinate system
    :return: a tuple (x,y) mapped to the dest coordinate system
    """
    x, y = point
    return x * dest_space_width / src_space_width, y * dest_space_height / src_space_height


def _convert_table_structure_to_pdf_space(table_structure: TableStructure, image_shape: Tuple[int, int],
                                          pdf_shape: Tuple[int, int]) -> TableStructure:
    coords_convert = partial(_convert_coordinate_system, dest_space_width=pdf_shape[0],
                             dest_space_height=pdf_shape[1], src_space_width=image_shape[0],
                             src_space_height=image_shape[1])

    table_structure.table_bbox = coords_convert(table_structure.table_bbox[0]), \
                                 coords_convert(table_structure.table_bbox[1])

    for row in table_structure.table_cells:
        for table_cell in row:
            table_cell.cell.top_left = coords_convert(table_cell.cell.top_left)
            table_cell.cell.bottom_right = coords_convert(table_cell.cell.bottom_right)

    return table_structure

