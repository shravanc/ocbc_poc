import os
os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="/Users/shravanc/Downloads/vision-project-a05a746e5354.json"
import io
from google.cloud import vision
from google.cloud.vision import types

import datetime


class Word:
    def __init__(self, text="", letters=""):
        self.text = text
        self.letters = letters


class Paragraph:

    def __init__(self, word_list):
        self.words = word_list


class Symbol:
    def __init__(self, symbol, end_of_word=False):
        # print("---initi--Symbol")
        self.symbol = symbol
        self.end_of_word = end_of_word


class MyGoogleVision:
    def __init__(self, image_path, vision_id):
        self.image_path = image_path
        self.vision_id = vision_id
        self.created_at = datetime.datetime.utcnow()
        self.data = {}

        self.words = []
        self.symbols = []
        self.paragraphs = []

        self.list = []

    def get_visioned(self):
        client = vision.ImageAnnotatorClient()
        
        with io.open(self.image_path, 'rb') as image_file:
            content = image_file.read()

        image = types.Image(content=content)

        response = client.document_text_detection(image=image)
        self.data = response.full_text_annotation

    def format_data(self):
        return {"created_at": self.created_at, "vision_id": self.vision_id, "data": self.data} 


    def make_sense(self):
        for page in self.data.pages:
            for block_index, block in enumerate(page.blocks):
                for index, paragraph in enumerate(block.paragraphs):
                    words = []
                    for word in paragraph.words:
                        letters = []
                        word_length = len(word.symbols)
                        for si, symbol in enumerate(word.symbols):
                            letters.append(symbol.text)
                            if si == (word_length-1):
                                self.symbols.append(Symbol(symbol, True))
                            else:
                                self.symbols.append(Symbol(symbol, False))
                        words.append(''.join(letters))
                        self.words.append(Word(''.join(letters)))
                    self.list.append(' '.join(words))
                    self.paragraphs.append(Paragraph(' '.join(words)))

    def display(self):
        print(self.list)
        
    # pdftotext -layout -x 144 -y 1437 -W 435 -H 127 "/Users/shravanc/flask/flask_apps/ocbc/app/uploads/page-1_121f1928-238e-11e9-a91b-1c36bb1a4426/pages/page-1.pdf" -
        
    def get_words(self, x=0, y=0, h=0, w=0):
        for sym in self.symbols:
            vertices = sym.symbol.bounding_box.vertices

            if vertices[0].x > x and vertices[1].x < (x+w):
                print(vertices[2].y - vertices[0].y)
                if vertices[0].y > y and (vertices[2].y - vertices[0].y + 50) > (90):
                    print(sym.symbol.text)
                    


#pdftotext -layout -x 144 -y 1437 -W 435 -H 127 "/Users/shravanc/flask/flask_apps/ocbc/app/uploads/page-1_121f1928-238e-11e9-a91b-1c36bb1a4426/pages/page-1.pdf" -

#pdftotext -layout -x 193 -y 1448 -W 254 -H 100 "/Users/shravanc/flask/flask_apps/ocbc/app/uploads/page-1_121f1928-238e-11e9-a91b-1c36bb1a4426/pages/page-1.pdf" -



    def test(self, x=198, y=1571, h=18, w=61):
        # print('*****************VISION_EXTRACTION*************', len(self.symbols), "---", )
        l_x = x #+ 660
        r_x = x+w
        l_y = y #+ 4700
        u_y = y + h

        letters = []
        # print(f"x={x}, y={y}, r_x={r_x}, u_y={u_y}")
        for sym in self.symbols:
            vertices = sym.symbol.bounding_box.vertices
            # if vertices[0].x >= l_x and vertices[1].x <= r_x:
                # print(f"x={x}, y={y}, r_x={r_x}, u_y={u_y}", sym.symbol.text)
                # print(f"-------------{sym.symbol.text}---------------------input-> x={vertices[0].x}, y={vertices[0].y}, r_x={vertices[1].x}, u_y={vertices[2].y}", vertices[0].y >= l_y and vertices[0].y <= (u_y))
            if vertices[0].x >= l_x and vertices[1].x <= r_x:
                if (vertices[0].y >= l_y and vertices[0].y <= (u_y)): # and vertices[2].y >= u_y:
                    # print(sym.symbol.text)
                    # print(sym.symbol.bounding_box.vertices)
                    letters.append(sym.symbol.text)
                    if sym.end_of_word:
                        letters.append(' ')

        # word = ''.join(letters)
        # print(word)
        return ''.join(letters)


    # def test(self, x=198, y=1571, h=18, w=61):
    #     # print('*****************VISION_EXTRACTION*************', len(self.symbols), "---", )
    #     l_x = x
    #     r_x = x+w
    #     l_y = y
    #     u_y = y + h
    #
    #     letters = []
    #     print(f"x={x}, y={y}, r_x={r_x}, u_y={u_y}")
    #     for sym in self.symbols:
    #         # print("------------Inside Iteration--------", sym.symbol.text, '-----')
    #         vertices = sym.symbol.bounding_box.vertices
    #         # print('----VISION_1-----')
    #         if vertices[0].x >= l_x and vertices[1].x <= r_x:
    #             # print('----VISION_2-----')
    #             # print(f"x={x}, y={y}, r_x={r_x}, u_y={u_y}", sym.symbol.text)
    #             print(f"-----------{sym.symbol.text}-----------------------input-> x={vertices[0].x}, y={vertices[0].y}, r_x={vertices[1].x}, u_y={vertices[2].y}", vertices[0].y >= l_y and vertices[0].y <= (u_y))
    #         if vertices[0].x >= l_x and vertices[1].x <= r_x:
    #             # print('----VISION_3-----')
    #             if (vertices[0].y >= l_y and vertices[0].y <= (u_y)): # and vertices[2].y >= u_y:
    #                 # print('----VISION_4-----')
    #                 # print(sym.symbol.text)
    #                 # print(sym.symbol.bounding_box.vertices)
    #                 letters.append(sym.symbol.text)
    #
    #     # print('----VISION_5-----')
    #     word = ''.join(letters)
    #     print(word)
    #     return ''.join(letters)



    # def test(self, x=198, y=1571, h=18, w=61):
    #     print('*****************VISION_EXTRACTION*************', len(self.symbols), "---", )
    #     l_x = x
    #     r_x = x+w
    #     l_y = y
    #     u_y = y + h
    #     print(f"x={x}, y={y}, r_x={r_x}, u_y={u_y}", self.symbols[0].symbol.text)
    #
    #     letters = []
    #     for sym in self.symbols:
    #         print("------------Inside Iteration--------", sym.symbol.text, '-----')
    #         vertices = sym.symbol.bounding_box.vertices
    #         print('----VISION_1-----')
    #
    #         if vertices[0].x >= l_x and vertices[1].x <= r_x:
    #             print('----VISION_2-----')
    #             print(f"x={x}, y={y}, r_x={r_x}, u_y={u_y}", sym.symbol.text)
    #             print(f"----------------------------------input-> x={vertices[0].x}, y={vertices[0].y}, r_x={vertices[1].x}, u_y={vertices[2].y}", vertices[0].y >= l_y and vertices[0].y <= (u_y))
    #         if vertices[0].x >= l_x and vertices[1].x <= r_x:
    #             print('----VISION_3-----')
    #             if (vertices[0].y >= l_y and vertices[0].y <= (u_y)): # and vertices[2].y >= u_y:
    #                 print('----VISION_4-----')
    #                 print(sym.symbol.text)
    #                 print(sym.symbol.bounding_box.vertices)
    #                 letters.append(sym.symbol.text)
    #
    #         print('----VISION_5-----')
    #         word = ''.join(letters)
    #         print(word)
    #         return word

