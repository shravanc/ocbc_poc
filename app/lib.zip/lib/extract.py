from typing import Tuple, List

import cv2 as cv
import numpy as np

def show_wait_destroy(winname, img):
    return True
    cv.imshow(winname, img)
    cv.moveWindow(winname, 500, 0)
    cv.waitKey(0)
    cv.destroyWindow(winname)

def _morph_open_and_find_contours(img: np.ndarray, kernel_size: Tuple[int, int]):
    open_kernel = cv.getStructuringElement(cv.MORPH_RECT, kernel_size)
    opened_img = cv.morphologyEx(img, cv.MORPH_OPEN, open_kernel)
    copy = opened_img.copy()
    _, contours, _ = cv.findContours(opened_img, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
    
    print("---COUNTOURS---", len(contours))
#    for cnt in contours:
#        print(len(cnt))
    #cnt = contours[0]
    #print(contours[4])
    #cnt = contours[4]
    cv.drawContours(copy, contours, -1, (0,255,0), 3)
    show_wait_destroy('Counters', copy)


    return opened_img, contours

def get_horizontal_and_vertical_contours(img , kernel_length_factor, kernel_width):
    kernel_length_factor = 55
    kernel_length_factor = 100
    kernel_size = ( int(img.shape[1] / kernel_length_factor), kernel_width )
    print(kernel_size)
    horizontal, hor_contours = _morph_open_and_find_contours(img, kernel_size )

    kernel_length_factor = 7
    kernel_length_factor = 110
    kernel_size = ( kernel_width, int(img.shape[0] / kernel_length_factor) )
    print("kernel_size--->", kernel_size)
    vertical, ver_contours   = _morph_open_and_find_contours(img, kernel_size)

    return [horizontal, hor_contours, vertical, ver_contours]

