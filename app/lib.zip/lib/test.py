import itertools
import numpy as np
import cv2 as cv
from collections import defaultdict
from os import path

from lib.extract import _morph_open_and_find_contours, get_horizontal_and_vertical_contours
from lib.utils import safe_pad_rect, _get_extreme_points, _point_in_rect, _get_pdf_page_dimensions, cv_contours_to_lines, _add_left_and_right_boundaries, safe_pad_line
from lib.core import find_intersections, find_cells, get_table_structure #, _convert_table_structure_to_pdf_space
from typing import Tuple, List
from lib.get_cordinates import _convert_table_structure_to_pdf_space
from lib.get_checkbox_info import construct_command
# from lib.crop_me import crop_image

from lib.check_box_data import CheckBox, CoOrdinate

TuplePoint = Tuple[int, int]


#img = './imgs/page-2.jpg'
#pdf = './pdfs/page-2.pdf'


#img = "./imgs/one_column.jpg"
#pdf = "./imgs/one_column.pdf"

#img = "./imgs/small_table.jpg"
#pdf = "./imgs/small_table.pdf"

#img = "./imgs/ocbc_1.jpg"
#pdf = "./pdfs/ocbc_1.pdf"

#img = "./imgs/ocbc_2.jpg"
#pdf = "./pdfs/ocbc_2.pdf"

#img = "./imgs/8.jpeg"
#img = "./imgs/8.DPI_72.jpeg"

#pdf = "./pdfs/8.pdf"
#pdf = "./pdfs/8.DPI_72.pdf"
#img = "./imgs/ocbc_checkbox_test.DPI_72.jpg"
#pdf = "./pdfs/ocbc_checkbox_test.DPI_72.pdf"


#img = "./imgs/6_check_box.jpg"
#pdf = "./pdfs/6_check_box.pdf"

# img = "./imgs/ocbc_1.DPI_73.jpg"
# pdf = "./pdfs/ocbc_1.DPI_73.pdf"

kernel_length_factor = 20
kernel_width = 1





def show_wait_destroy(winname, img):
    cv.imshow(winname, img)
    cv.moveWindow(winname, 500, 0)
    cv.waitKey(0)
    cv.destroyWindow(winname)


def write_image(name, img, countours=None):
    name = "./checkbox_output/" + name
    if countours is not None:
#        cnt = countours[4]
        new_copy = img.copy()
        cv.drawContours(new_copy, countours, -1, [0, 0, 255], thickness=2)
        cv.imwrite(name, new_copy)
    else:
        new_copy = img.copy()
        cv.imwrite(name, img)
      
      
def extract_tables(image_path: str, pdf_path: str, debug=False, debug_folder_path=""):
    check_box = CheckBox(image_path, pdf_path)
    image = cv.imread(image_path)
    if image is None:
        raise AssertionError('Error opening image: ' + image_path)

    # gray covertion
    gray_image = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

    # apply thresholding
    _, thresholded_inverted_image = cv.threshold(gray_image, 175, 255, cv.THRESH_BINARY_INV + cv.THRESH_OTSU)
    write_image('thresholded_inverted.jpg', thresholded_inverted_image)
    
    horizontal, hor_contours, vertical, ver_contours = get_horizontal_and_vertical_contours(thresholded_inverted_image, kernel_length_factor, kernel_width)
    lines_img = vertical + horizontal
    lines_img = cv.morphologyEx(lines_img, cv.MORPH_CLOSE, np.full((10, 10), 255, dtype=np.uint8))

    _, lines_contours, lines_contour_hierarchy = cv.findContours(lines_img, cv.RETR_CCOMP, cv.CHAIN_APPROX_SIMPLE)


    # Remove all contours that have no parents(h[3]). This will give all level 1 contours.
    parent_contours = [c for c, h in zip(lines_contours, lines_contour_hierarchy[0].tolist()) if h[3] == -1]

    write_image('hor_and_ver_contours.jpg', image, (hor_contours + ver_contours))
    write_image('parent_contours.jpg', image, parent_contours)
    write_image('lines.jpg', lines_img )
    write_image('vertical.jpg', vertical)
    write_image('horizontal.jpg', horizontal)
    write_image('thresholded_inverted.jpg', thresholded_inverted_image)
    write_image('gray.jpg', gray_image)


    total_area = image.shape[0] * image.shape[1]
   
    rects = []
    for i, contour in enumerate(parent_contours):

        # Maximum and minimum area check
        x, y, w, h = cv.boundingRect(cv.approxPolyDP(contour, 3, True))
        #print("===========")
        print("x = {}, y = {}, w = {}, h = {}".format(x, y, w, h))
        bounding_box_area = w * h
        #print(bounding_box_area)
        relative_area = bounding_box_area / total_area * 100
        #print(relative_area)
        #print("1===========")
        #if relative_area > 70 or relative_area < 9:
        #    continue

        #print( (((x, y), (x + w, y + h)), ((0, 0), (image.shape[1], image.shape[0])), 1) )
        # Passes all checks
        rects.append(safe_pad_rect(((x, y), (x + w, y + h)), ((0, 0), (image.shape[1], image.shape[0])), 1))


    rect_to_contour_dict = defaultdict(list)
    for contour in itertools.chain(hor_contours, ver_contours):
        [ext_left, ext_top, ext_right, ext_bot] = _get_extreme_points(contour)
        for rect in rects:
#            print("rects====>", rect)
            if _point_in_rect(ext_left, rect) \
                    or _point_in_rect(ext_top, rect) \
                    or _point_in_rect(ext_right, rect) \
                    or _point_in_rect(ext_bot, rect):
                rect_to_contour_dict[rect].append(contour)
                break

    #print("***rect_to_contour_dict***", rect_to_contour_dict)
    image_width, image_height = image.shape[1], image.shape[0]
    #print("image_width==>", image_width, "image_height==>", image_height)
    pdf_width, pdf_height = _get_pdf_page_dimensions(pdf_path, 0)
    #print("pdf_width==>", pdf_width, "pdf_height==>", pdf_height)
    table_structures = []
    all_lines = []
    for rect, contours in rect_to_contour_dict.items():
        lines = cv_contours_to_lines(contours)
        lines = _add_left_and_right_boundaries(lines, debug=True)
        lines = [safe_pad_line(l, (image_width, image_height), 2) for l in lines]
        all_lines += lines

        intersections = find_intersections(lines)
        cells = find_cells(intersections)
        table_structure = get_table_structure(cells)
        table_structure.table_bbox = rect
        table_structures.append(table_structure)


    write_image('ds_lines.jpg', image) 

    print('---COUNT---')
    print(len(table_structures))


    image_copy = np.copy(image)
    cv.rectangle(image_copy, (50, 50), (200, 200), [0, 0, 255], thickness=5)
    for row in table_structures[0].table_cells:
        for table_cell in row:
            cv.rectangle(image_copy, tuple(table_cell.cell.top_left), tuple(table_cell.cell.bottom_right), [0, 0, 255],
                         thickness=5)
    cv.imwrite(path.join(debug_folder_path, "cells.jpg"), image_copy)

    tables = sorted([_convert_table_structure_to_pdf_space(t, (image_width, image_height), (pdf_width, pdf_height))
                   for t in table_structures], key=lambda t: t.table_bbox[0][1])


    check_box.cv_image = image
    for ti, table in enumerate(tables):
        table_cells = table.table_cells
        for ri, row in enumerate(table_cells):
            for ci, col in enumerate(row):
                co_ordinates, pdf_text_cmd = construct_command(col, pdf_path)
                id = str(ti) + str(ri) + str(ci)
                #if co_ordinates['w'] != 0 and co_ordinates['w'] >4 and co_ordinates['h'] >6 :
                if co_ordinates['y'] > 400 and co_ordinates['y'] < 600 and co_ordinates['w'] >10 and co_ordinates['w'] < 30 and co_ordinates['h'] >8:
                    check_box.co_ordinates.append( CoOrdinate(id, co_ordinates, 'constitution') )
                    print(f"{id} -> {co_ordinates}")
                elif co_ordinates['y'] > 790 and co_ordinates['y'] < 970 and co_ordinates['w'] >10 and co_ordinates['h'] >8:
                    check_box.co_ordinates.append( CoOrdinate(id, co_ordinates, 'finance_facilities') )
                    print(f"{id} -> {co_ordinates}")
                else:
                    pass
#                    print(co_ordinates)


    return check_box

# if __name__ == '__main__':
#     extract_tables(img, pdf)



