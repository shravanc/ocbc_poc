


def construct_command(col, pdf_path):
    co_ordinates = {"x": int(col.cell.top_left[0]),
                    "y": int(col.cell.top_left[1]),
                    "w": (int((col.cell.bottom_right[0]) - (col.cell.top_left[0]))),
                    "h": int((col.cell.bottom_right[1]) - (col.cell.top_left[1]))
                    }
    return [co_ordinates, "pdftotext -layout -x " + str(int(col.cell.top_left[0])) + " -y " + str(
                int(col.cell.top_left[1])) + " -W " + str(int(
                (col.cell.bottom_right[0]) - (col.cell.top_left[0]))) + " -H " + str(int(
                (col.cell.bottom_right[1]) - (col.cell.top_left[1]))) + " \"" + pdf_path + "\" - "]


