# MorningStar
POC for data extraction from Nepali PDF.
