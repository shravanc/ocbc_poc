import numpy as np
from typing import Tuple, List
from PyPDF2 import PdfFileReader
import cv2 as cv
from lib.structure import Line, Point

TuplePoint = Tuple[int, int]

def safe_pad_rect(rect, bg_rect, padding):
    bg_tl_x, bg_tl_y = bg_rect[0]
    bg_br_x, bg_br_y = bg_rect[1]

    rect_tl_x, rect_tl_y = rect[0]
    rect_br_x, rect_br_y = rect[1]

    padded_tl_x = rect_tl_x - padding
    padded_tl_y = rect_tl_y - padding
    padded_br_x = rect_br_x + padding
    padded_br_y = rect_br_y + padding

    if padded_tl_x < bg_tl_x:
        padded_tl_x = bg_tl_x

    if padded_tl_y < bg_tl_y:
        padded_tl_y = bg_tl_y

    if padded_br_x > bg_br_x:
        padded_br_x = bg_br_x

    if padded_br_y > bg_br_y:
        padded_br_y = bg_br_y

    return (padded_tl_x, padded_tl_y), (padded_br_x, padded_br_y)

def _get_extreme_points(contour: np.ndarray) -> Tuple[TuplePoint, TuplePoint, TuplePoint, TuplePoint]:
    ext_left = tuple(contour[contour[:, :, 0].argmin()][0])
    ext_right = tuple(contour[contour[:, :, 0].argmax()][0])
    ext_top = tuple(contour[contour[:, :, 1].argmin()][0])
    ext_bot = tuple(contour[contour[:, :, 1].argmax()][0])

    print("ext_left--->",ext_left, "ext_right--->", ext_right, "ext_top--->", ext_top, "ext_bot--->", ext_bot)
    return ext_left, ext_top, ext_right, ext_bot

def _point_in_rect(point: TuplePoint, rect: [TuplePoint, TuplePoint]) -> bool:
    (tl_x, tl_y), (br_x, br_y) = rect
    x, y = point
    return tl_x <= x <= br_x and tl_y <= y <= br_y

def _get_pdf_page_dimensions(pdf_file_path, page_no):
    """
    Gets the height and width of the pdf at the given page no after the rotation is applied. The default height and
    width are swapped when the pdf has a rotation of 90/270(vertical).
    :param pdf_file_path: File path of the input pdf
    :param page_no: Page no whose dimensions are returned
    :return: A tuple of the form (width, height)
    """
    with open(pdf_file_path, 'rb') as file:
        pdf_file = PdfFileReader(file).getPage(page_no)
        media_box = pdf_file.mediaBox
        rotation = pdf_file.get('/Rotate')

        if is_horizontal_orientation(rotation):
            w, h = media_box.getWidth(), media_box.getHeight()
        else:
            w, h = media_box.getHeight(), media_box.getWidth()

        return w, h

def is_horizontal_orientation(rotation_angle):
    if rotation_angle == 0 or rotation_angle is None:
        return True
    elif rotation_angle == 90:
        return False

    if rotation_angle % 180 == 0:
        return True

    return False


def cv_contours_to_lines(contours):
    lines = []
    for contour in contours:
        x, y, width, height = cv.boundingRect(contour)

        if width > height:
            line_y = int((y + (y + height)) / 2)
            lines.append(Line(Point(x, line_y), Point(x + width - 1, line_y)))
        else:
            line_x = int((x + (x + width)) / 2)
            lines.append(Line(Point(line_x, y), Point(line_x, y + height - 1)))
    return lines

def is_horizontal_orientation(rotation_angle):
    if rotation_angle == 0 or rotation_angle is None:
        return True
    elif rotation_angle == 90:
        return False

    if rotation_angle % 180 == 0:
        return True

    return False

def cv_contours_to_lines(contours):
    lines = []
    for contour in contours:
        x, y, width, height = cv.boundingRect(contour)

        if width > height:
            line_y = int((y + (y + height)) / 2)
            lines.append(Line(Point(x, line_y), Point(x + width - 1, line_y)))
        else:
            line_x = int((x + (x + width)) / 2)
            lines.append(Line(Point(line_x, y), Point(line_x, y + height - 1)))
    return lines


def _add_left_and_right_boundaries(lines: List[Line],
                                   max_allowed_vertical_boundary_inset_percent=3, debug=False) -> List[Line]:
    hor_lines = [l for l in lines if l.is_horizontal()]
    ver_lines = [l for l in lines if l.is_vertical()]

    if len(ver_lines) == 0 or len(hor_lines) == 0:
        return lines

    # Ensure for horizontal lines start.x <= end.x
    for hor_line in hor_lines:
        if hor_line.start.x > hor_line.end.x:
            hor_line.start, hor_line.end = hor_line.end, hor_line.start

    # Ensure for vertical lines start.y <= end.y
    for ver_line in ver_lines:
        if ver_line.start.y > ver_line.end.y:
            ver_line.start, ver_line.end = ver_line.end, ver_line.start

    # Extreme points of the table
    top_max = min(hor_lines, key=lambda h_line: h_line.start.y).start.y
    bottom_max = max(hor_lines, key=lambda h_line: h_line.end.y).end.y
    left_max = min(hor_lines, key=lambda h_line: h_line.start.x).start.x
    right_max = max(hor_lines, key=lambda v_line: v_line.end.x).end.x

    width = right_max - left_max

    left_boundary_line_x = min([l.start.x for l in ver_lines])
    left_inset = abs(left_boundary_line_x - left_max) / width * 100
    # if debug:
        # print(f"left_inset={left_inset}")
    if left_inset > max_allowed_vertical_boundary_inset_percent:
        lines.append(Line(Point(left_max, top_max), Point(left_max, bottom_max)))
        #Extend horizontal lines to meet left boundary
        for l in hor_lines:
            l.start.x = left_max


    right_boundary_line_x = max([l.end.x for l in ver_lines])
    right_inset = abs(right_max - right_boundary_line_x) / width * 100

    # if debug:
        # print(f"right_inset={right_inset}")
    if right_inset > max_allowed_vertical_boundary_inset_percent:
        lines.append(Line(Point(right_max, top_max), Point(right_max, bottom_max)))
        #Extend horizontal lines to meet the right boundary
        for l in hor_lines:
            l.end.x = right_max

    return lines

def safe_pad_line(line, bg_dimension, padding):
    bg_width, bg_height = bg_dimension

    if line.is_horizontal():
        ends_reversed = line.start.x > line.end.x

        x_left, x_right = (line.end.x, line.start.x) if ends_reversed else (line.start.x, line.end.x)

        x_left = x_left - padding
        x_right = x_right + padding

        if x_left < 0:
            x_left = 0

        if x_right > bg_width:
            x_right = bg_width

        start_point, end_point = (Point(x_right, line.start.y), Point(x_left, line.start.y)) if ends_reversed \
            else (Point(x_left, line.end.y), Point(x_right, line.start.y))
        return Line(start=start_point, end=end_point)
    elif line.is_vertical():
        ends_reversed = line.start.y > line.end.y

        y_top, y_bottom = (line.end.y, line.start.y) if ends_reversed else (line.start.y, line.end.y)

        y_top = y_top - padding
        y_bottom = y_bottom + padding

        if y_top < 0:
            y_top = 0

        if y_bottom > bg_height:
            y_bottom = bg_height

        start_point, end_point = (Point(line.start.x, y_bottom), Point(line.start.x, y_top)) if ends_reversed \
            else (Point(line.start.x, y_top), Point(line.start.x, y_bottom))
        return Line(start=start_point, end=end_point)
    else:
        raise ValueError("Can only process horizontal and vertical lines")

