import subprocess
from lib.crop_me import crop_image
import cv2 as cv
# from save_image import write_image

save_path = "./checked_test/"
def get_image_path(file_name):
  return (save_path + file_name)

def get_cordinates(col):
    return {"x": int(col.cell.top_left[0]),
            "y": int(col.cell.top_left[1]),
            "w": (int((col.cell.bottom_right[0]) - (col.cell.top_left[0]))),
            "h": int((col.cell.bottom_right[1]) - (col.cell.top_left[1]))
            }

class CoOrdinate():
    def __init__(self, id, data, field=""):
        self.id = id
        self.x = data['x']
        self.y = data['y']
        self.h = data['h']
        self.w = data['w']
        self.checked = False
        self.text    = ""
        self.field   = field

    def print_co(self):
        print(f"id-> {self.id}, x->{self.x}, y->{self.y}, w->{self.w}, h->{self.h}")

class CheckBox():
    def __init__(self, image, pdf, cv_image=None):
        self.co_ordinates = []
        self.check_box_location = []
        self.parsed_id = []
        self.image = image
        self.pdf   = pdf
        self.cv_image = cv.imread(image) #cv_image
        self.response = []
        self.required_data = []

    def generate_response(self):
        for loc in self.check_box_location:
            for each_box in loc:
                self.response.append({"checked": each_box.checked, "text": each_box.text, "field": each_box.field})
                if each_box.checked:
                    self.required_data.append({"checked": each_box.checked, "text": each_box.text, "field": each_box.field})


    def find_check_box_on_same_line(self, cb):
        if cb.id in self.parsed_id:
            return True
        self.parsed_id.append(cb.id)
        locations = [cb]
       

        for co in self.co_ordinates:
            if cb.id != co.id:
                if co.id in self.parsed_id:
                    continue
                print("------START------", self.parsed_id)
                cb.print_co()
                co.print_co()
                print(f"co.y-->{co.y}, cb.y-->{cb.y}")
                if (co.y > (cb.y-5)) and ( (co.y - cb.y) < 10 ):
                    #print("-------ACCEPTED------")
                    self.parsed_id.append(co.id)
                    locations.append(co)
                #print("------END------")

        self.check_box_location.append(locations)

    def structure_check_box(self):
        for co in self.co_ordinates:
            self.find_check_box_on_same_line(co)

    def pdf_text_command(self, x, y, w, h):
        return "pdftotext -layout -x " + str(x) + " -y " + str(y)  + " -W " + str(w) + " -H " + str(h) + " " + self.pdf + " -"

    def is_checked(self, locations):
        for index,co in enumerate(locations):
            cropped_image = crop_image( self.cv_image.copy(), (co.x+2, co.y+2), ((co.x+co.w-1 ), (co.y+co.h -1))) 
            # write_image(get_image_path(f"cropped_image_{co.id}.jpg"), cropped_image)

            imgray = cv.cvtColor(cropped_image,cv.COLOR_BGR2GRAY)
            # write_image(get_image_path(f"gray_image_{co.id}.jpg"), imgray)

            ret,thresh = cv.threshold(imgray,127,255, cv.THRESH_BINARY_INV)
            # write_image(get_image_path(f"inverted_image_{co.id}.jpg"), thresh)

            count = cv.countNonZero(thresh)
            #print("---COUNT---->", count)
            total_area = cropped_image.shape[0] * cropped_image.shape[1]

            percent = int((count / total_area) * 100)
            print("Percent----->", percent, co.id)
            if percent > 5:
                co.checked = True

    def extract_text(self):
        self.structure_check_box()
        print("---->TOTAL_CHECKBOX--->", len(self.check_box_location))
        for loc in self.check_box_location:
            self.is_checked(loc)
      
            for each_box in loc:
                x = each_box.x + each_box.w
                w = 315
                y = each_box.y
                h = each_box.h
              
                pdf_text_cmd = self.pdf_text_command(x, y, w, h)
                pdf_text_process = subprocess.Popen(pdf_text_cmd, shell=True, stdout=subprocess.PIPE)
                each_box.text = pdf_text_process.communicate()[0]
            

